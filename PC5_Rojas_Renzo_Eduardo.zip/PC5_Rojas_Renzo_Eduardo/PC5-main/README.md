# PC5
Detalle Problemas PC5 Curso Python
